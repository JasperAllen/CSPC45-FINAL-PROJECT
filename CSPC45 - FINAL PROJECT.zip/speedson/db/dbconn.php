<?php
$conn = mysqli_connect("localhost", "root", "", "alphaware") or die(mysqli_error($conn));
