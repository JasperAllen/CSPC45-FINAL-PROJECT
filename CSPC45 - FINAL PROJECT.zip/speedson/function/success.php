<?php
include("../db/dbconn.php");
$item_no            = $_REQUEST['PayerID'];
$tid            = $_REQUEST['tid'];
$price = '10.00';
$currency = 'USD';

if (!empty($item_no)) {
    $query = mysqli_query($conn, "UPDATE transaction set order_stat = 'Confirmed' WHERE transaction_id = $tid  ") or die(mysqli_error($conn) . "UPDATE trasaction set order_stat = 'Confirmed' WHERE trasaction_id = $tid  ");
    echo "<script>alert('Order Confirmed!')</script>";
    header('location:../home.php');
} else {
    $content = "<h1>Payment Failed</h1>";
}

$title = "PayPal Payment in PHP";
$heading = "Welcome to PayPal Payment PHP example.";
