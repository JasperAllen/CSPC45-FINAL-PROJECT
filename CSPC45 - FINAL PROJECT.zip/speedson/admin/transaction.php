<?php
include("../function/session.php");
include("../db/dbconn.php");
?>
<!DOCTYPE html>
<html>

<head>
	<title>SpeedSon E-commerce</title>
	<link rel="stylesheet" type="text/css" href="../css/style.css" media="all">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">

	<script src="../js/jquery-1.7.2.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>
	<script src="../javascripts/filter.js"></script>

	<!--Le Facebox-->
	<link href="../facefiles/facebox.css" rel="stylesheet" />
	<script src="../facefiles/jquery-1.9.js"></script>
	<script src="../facefiles/jquery-1.2.2.pack.js"></script>
	<script src="../facefiles/facebox.js"></script>
	<script>
		jQuery(document).ready(function($) {
			$('a[rel*=facebox]').facebox();
		});
	</script>
</head>

<body>
	<div class="container-fluid">
		<div class="row">
			<div id="header" style="position:fixed;">
				<img src="../img/logo.jpg">
				<label>SpeedSon</label>

				<?php
				$adminName = "Admin";
				if (isset($_SESSION['id'])) {
					$id = (int) $_SESSION['id'];
					$query = mysqli_query($conn, "SELECT * FROM admin WHERE adminid = '$id'") or die(mysqli_error($conn));
					if (mysqli_num_rows($query) > 0) {
						$fetch = mysqli_fetch_array($query);
						$adminName = htmlspecialchars($fetch['username']);
					}
				}
				?>

				<ul>
					<li><a href="../function/admin_logout.php" class="btn btn-danger text-white"><i class="icon-off icon-white"></i>LOGOUT</a></li>
					<li style="font-size: 14px;">Welcome:&nbsp;&nbsp;&nbsp;<a class="btn btn-primary text-white mx-1"><i class="icon-user icon-white"></i><?php echo $adminName; ?></a></li>
				</ul>
			</div>

			<div id="add" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="width:400px;">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">x</button>
					<h3 id="myModalLabel">Add Product...</h3>
				</div>
				<div class="modal-body">
					<form method="post" enctype="multipart/form-data">
						<center>
							<table>
								<tr>
									<td><input type="file" name="product_image" required></td>
								</tr>
								<?php include("random_id.php"); ?>
								<tr>
									<td><input type="hidden" name="product_code" value="<?php echo $code; ?>"></td>
								</tr>
								<tr>
									<td><input type="text" name="product_name" placeholder="Product Name" style="width:250px;" required></td>
								</tr>
								<tr>
									<td><input type="text" name="product_price" placeholder="Price" style="width:250px;" required></td>
								</tr>
								<tr>
									<td><input type="text" name="product_size" placeholder="Size" style="width:250px;" maxlength="2" required></td>
								</tr>
								<tr>
									<td><input type="text" name="brand" placeholder="Brand Name" style="width:250px;" required></td>
								</tr>
								<tr>
									<td><input type="number" name="qty" placeholder="No. of Stock" style="width:250px;" required></td>
								</tr>
								<tr>
									<td><input type="hidden" name="category" value="basketball"></td>
								</tr>
							</table>
						</center>
				</div>
				<div class="modal-footer">
					<input class="btn btn-primary" type="submit" name="add" value="Add">
					<button class="btn btn-danger" data-dismiss="modal">Close</button>
					</form>
				</div>
			</div>

			<?php
			if (isset($_POST['add'])) {
				$product_code = $_POST['product_code'];
				$product_name = $_POST['product_name'];
				$product_price = $_POST['product_price'];
				$product_size = $_POST['product_size'];
				$brand = $_POST['brand'];
				$category = $_POST['category'];
				$qty = $_POST['qty'];
				$code = rand(0, 98987787866533499);

				$name = $code . basename($_FILES["product_image"]["name"]);
				$size = $_FILES["product_image"]["size"];
				$temp = $_FILES["product_image"]["tmp_name"];
				$error = $_FILES["product_image"]["error"];

				if ($error > 0) {
					die("Error uploading file! Code $error.");
				} elseif ($size > 30000000000) {
					die("Format is not allowed or file size is too big!");
				} else {
					move_uploaded_file($temp, "../photo/" . $name);

					$q1 = mysqli_query($conn, "INSERT INTO product (product_id, product_name, product_price, product_size, product_image, brand, category) VALUES ('$product_code','$product_name','$product_price','$product_size','$name', '$brand', '$category')");
					$q2 = mysqli_query($conn, "INSERT INTO stock (product_id, qty) VALUES ('$product_code','$qty')");

					header("location:admin_product.php");
					exit;
				}
			}
			?>

			<div id="leftnav">
				<ul>
					<li><a href="admin_home.php">Dashboard</a></li>
					<li><a href="admin_home.php">Products</a>
						<ul>
							<li><a href="admin_feature.php" style="margin-left:15px;">Features</a></li>
							<li><a href="admin_product.php" style="margin-left:15px;">Basketball</a></li>
							<li><a href="admin_football.php" style="margin-left:15px;">Football</a></li>
							<li><a href="admin_running.php" style="margin-left:15px;">Running</a></li>
						</ul>
					</li>
					<li><a href="transaction.php">Transactions</a></li>
					<li><a href="customer.php">Customers</a></li>
					<li><a href="message.php">Messages</a></li>
					<li><a href="order.php">Orders</a></li>
				</ul>
			</div>

			<div id="rightcontent" style="position:absolute; top:12%;">
				<div class="alert alert-info text-center">
					<h2 style="text-align: center;">Transactions</h2>
				</div>

				<label class="float-right p-2" style="float: top right; margin-left: 805px;"><input type="text" name="filter" placeholder="Search Transactions here..." id="filter"></label>

				<div class="alert alert-info">
					<table class="table table-hover">
						<thead>
							<tr style="font-size:16px;">
								<th>ID</th>
								<th>DATE</th>
								<th>Customer Name</th>
								<th>Total Amount</th>
								<th>Order Status</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							<?php
							$query = mysqli_query($conn, "SELECT * FROM transaction LEFT JOIN customer ON customer.customerid = transaction.customerid") or die(mysqli_error($conn));
							while ($fetch = mysqli_fetch_array($query)) {
								$id = $fetch['transaction_id'];
								$amnt = $fetch['amount'];
								$o_stat = $fetch['order_stat'];
								$o_date = $fetch['order_date'];
								$name = $fetch['firstname'] . ' ' . $fetch['lastname'];
							?>
								<tr>
									<td><?php echo $id; ?></td>
									<td><?php echo $o_date; ?></td>
									<td><?php echo $name; ?></td>
									<td><?php echo $amnt; ?></td>
									<td><?php echo $o_stat; ?></td>
									<td>
										<a href="receipt.php?tid=<?php echo $id; ?>">View</a>
										<?php
										if ($o_stat != 'Confirmed' && $o_stat != 'Cancelled') {
											echo '| <a class="btn btn-mini btn-info" href="confirm.php?id=' . $id . '">Confirm</a> ';
											echo '| <a class="btn btn-mini btn-danger" href="cancel.php?id=' . $id . '">Cancel</a>';
										}
										?>
									</td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>

			<?php
			if (isset($_POST['stockin'])) {
				$pid = $_POST['pid'];
				$result = mysqli_query($conn, "SELECT * FROM stock WHERE product_id='$pid'") or die(mysqli_error($conn));
				$row = mysqli_fetch_array($result);

				$total = $row['qty'] + $_POST['new_stck'];
				mysqli_query($conn, "UPDATE stock SET qty = '$total' WHERE product_id='$pid'") or die(mysqli_error($conn));
				header("Location:admin_product.php");
				exit;
			}

			if (isset($_POST['stockout'])) {
				$pid = $_POST['pid'];
				$result = mysqli_query($conn, "SELECT * FROM stock WHERE product_id='$pid'") or die(mysqli_error($conn));
				$row = mysqli_fetch_array($result);

				$total = $row['qty'] - $_POST['new_stck'];
				mysqli_query($conn, "UPDATE stock SET qty = '$total' WHERE product_id='$pid'") or die(mysqli_error($conn));
				header("Location:admin_product.php");
				exit;
			}
			?>
		</div>
	</div>
</body>

</html>

<script>
	$(document).ready(function() {
		$('.remove').click(function() {
			var id = $(this).attr("id");
			if (confirm("Are you sure you want to delete this product?")) {
				$.ajax({
					type: "POST",
					url: "../function/remove.php",
					data: {
						id: id
					},
					cache: false,
					success: function(html) {
						$(".del" + id).fadeOut(2000, function() {
							$(this).remove();
						});
					}
				});
			}
		});
	});
</script>