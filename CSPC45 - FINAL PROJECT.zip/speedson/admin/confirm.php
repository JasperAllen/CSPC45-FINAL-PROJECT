<?php
include("../db/dbconn.php");

function handleDbError($conn, $message)
{
	// You can log errors here if needed
	die("Database error: $message - " . mysqli_error($conn));
}

$t_id = $_GET['id'] ?? null;
if (!$t_id) {
	die("Invalid transaction ID.");
}

// Update transaction status
if (!mysqli_query($conn, "UPDATE transaction SET order_stat = 'Confirmed' WHERE transaction_id = '$t_id'")) {
	handleDbError($conn, "Failed to update transaction status");
}

// Get transaction details
$query2 = mysqli_query($conn, "
    SELECT * FROM transaction_detail 
    LEFT JOIN product ON product.product_id = transaction_detail.product_id 
    WHERE transaction_detail.transaction_id = '$t_id'
") or handleDbError($conn, "Failed to fetch transaction details");

while ($row = mysqli_fetch_array($query2)) {
	$pid = $row['product_id'];
	$oqty = $row['order_qty'];

	// Get stock info
	$query3 = mysqli_query($conn, "SELECT * FROM stock WHERE product_id = '$pid'")
		or handleDbError($conn, "Failed to fetch stock for product ID $pid");

	$row3 = mysqli_fetch_array($query3);
	$stck = $row3['qty'];
	$stck_out = $stck - $oqty;

	// Update stock
	$updateStock = mysqli_query($conn, "UPDATE stock SET qty = '$stck_out' WHERE product_id = '$pid'")
		or handleDbError($conn, "Failed to update stock for product ID $pid");
}

header("Location: transaction.php");
exit();
