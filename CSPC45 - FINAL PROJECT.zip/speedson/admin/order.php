<?php
include("../function/session.php");
include("../db/dbconn.php");
?>
<!DOCTYPE html>
<html>

<head>
	<title>SpeedSon E-commerce</title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<script src="../js/jquery-1.7.2.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>

	<link href="../facefiles/facebox.css" rel="stylesheet">
	<script src="../facefiles/jquery-1.9.js"></script>
	<script src="../facefiles/jquery-1.2.2.pack.js"></script>
	<script src="../facefiles/facebox.js"></script>
	<script>
		jQuery(document).ready(function($) {
			$('a[rel*=facebox]').facebox()
		});
	</script>
</head>

<body>
	<div class="container-fluid">
		<div class="row">

			<div id="header" style="position:fixed;">
				<img src="../img/logo.jpg">
				<label>SpeedSon</label>

				<?php
				$id = isset($_SESSION['id']) ? (int)$_SESSION['id'] : 0;
				$query = mysqli_query($conn, "SELECT * FROM admin WHERE adminid = '$id'") or die(mysqli_error($conn));
				$fetch = mysqli_fetch_array($query);
				$username = isset($fetch['Username']) ? $fetch['Username'] : 'Admin';
				?>

				<ul>
					<li><a href="../function/admin_logout.php" class="btn btn-danger text-white"><i class="icon-off icon-white"></i>LOGOUT</a></li>
					<li style="font-size: 1;">Welcome:&nbsp;&nbsp;&nbsp;<a class="btn btn-primary text-white mx-1"><i class="icon-user icon-white"></i><?php echo $username; ?></a></li>
				</ul>
			</div>

			<div id="leftnav">
				<ul>
					<li><a href="admin_home.php">Dashboard</a></li>
					<li><a href="admin_home.php">Products</a>
						<ul>
							<li><a href="admin_feature.php" style="font-size:15px; margin-left:15px;">Features</a></li>
							<li><a href="admin_product.php" style="font-size:15px; margin-left:15px;">Basketball</a></li>
							<li><a href="admin_football.php" style="font-size:15px; margin-left:15px;">Football</a></li>
							<li><a href="admin_running.php" style="font-size:15px; margin-left:15px;">Running</a></li>
						</ul>
					</li>
					<li><a href="transaction.php">Transactions</a></li>
					<li><a href="customer.php">Customers</a></li>
					<li><a href="message.php">Messages</a></li>
					<li><a href="order.php" style="font-weight:bold;">Orders</a></li>
				</ul>
			</div>

			<div id="rightcontent" style="position:absolute; top:12%;">
				<div class="alert alert-info">
					<center>
						<h2>Orders</h2>
					</center>
				</div>
				<br />
				<div class="alert alert-info">
					<table class="table table-hover">
						<thead>
							<tr>
								<th>SHOE</th>
								<th>Transaction No.</th>
								<th>AMOUNT</th>
							</tr>
						</thead>
						<tbody>
							<?php
							$Q1 = mysqli_query($conn, "SELECT * FROM transaction WHERE order_stat = 'Confirmed'");
							while ($r1 = mysqli_fetch_assoc($Q1)) {
								$tid = $r1['transaction_id'];

								$Q2 = mysqli_query($conn, "SELECT * FROM transaction_detail 
							LEFT JOIN product ON product.product_id = transaction_detail.product_id 
							WHERE transaction_detail.transaction_id = '$tid'");
								if ($Q2) {
									while ($r2 = mysqli_fetch_assoc($Q2)) {
										$brand = $r2['product_name'] ?? 'Unknown';
										$p_price = $r2['product_price'] ?? 0;

										echo "<tr>";
										echo "<td>" . htmlspecialchars($brand) . "</td>";
										echo "<td>" . htmlspecialchars($tid) . "</td>";
										echo "<td>" . formatMoney($p_price) . "</td>";
										echo "</tr>";
									}
								}
							}

							$Q3 = mysqli_query($conn, "SELECT SUM(amount) AS total FROM transaction WHERE order_stat = 'Confirmed'");
							$r3 = mysqli_fetch_assoc($Q3);
							$amnt = $r3 && isset($r3['total']) ? $r3['total'] : 0;

							echo "<tr><td></td><td><strong>TOTAL:</strong></td><td><b>Php " . formatMoney($amnt) . "</b></td></tr>";
							?>
						</tbody>
					</table>
				</div>

				<?php
				function formatMoney($number, $fractional = false)
				{
					if ($fractional) {
						$number = sprintf('%.2f', $number);
					}
					while (true) {
						$replaced = preg_replace('/(-?\d+)(\d\d\d)/', '$1,$2', $number);
						if ($replaced != $number) {
							$number = $replaced;
						} else {
							break;
						}
					}
					return $number;
				}
				?>
			</div>

		</div>
	</div>
</body>

</html>